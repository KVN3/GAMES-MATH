﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace DijkstraStudent
{
  public class DijkstraAlgorithm
  {
    public DisplayGraphDelegate DisplayGraph { get; set; }

    public DijkstraAlgorithm()
    {
      // ...
    }

    public void CalculateShortestPaths(Graph graph, Node startingNode)
    {
      // step 1...

      // step 2...

      // continue the algorithm, while there are more nodes to check
      while (true)
      {
        // step 3...

        // update interface
        DisplayGraph(startingNode);

        // step 4...

        // update interface
        DisplayGraph(startingNode);
      }
    }
  }
}